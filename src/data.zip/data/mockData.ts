import { Department, Contributors } from "./dataTypes";

export const departments: Department[] = [
  {
    name: "Computer Science, ISE, AIML",
    description: "Study materials for Computer Science, Information Science, and AI/ML covering various subjects across programming, computer systems, and artificial intelligence.",
    link: "/cse-ise-aiml",
    years: [
      {
        year: 1,
        semesters: [
          {
            number: 1,
            subjects: [
              {
                name: "Programming in C",
                subject_code: "CSE101",
                notes: [
                  {
                    title: "Programming in C Lab",
                    type: "lab",
                    link: "https://github.com/KTS-o7/PIC_Lab_programs_RVCE.git"
                  }
                ]
              },
              {
                name: "IDEA Lab",
                subject_code: "CSE102",
                notes: [
                  {
                    title: "IDEA Lab Materials",
                    type: "lab",
                    link: "https://github.com/Developer1100x/RVCE_Idea_lab_2021B"
                  }
                ]
              }
            ]
          }
        ]
      },
      {
        year: 2,
        semesters: [
          {
            number: 3,
            subjects: [
              {
                name: "DMS",
                subject_code: "CSE201",
                notes: [
                  {
                    title: "DMS Study Materials",
                    type: "theory",
                    link: "https://drive.google.com/drive/folders/1xlmj_VtgrJMUYgSi_3Z7bH87MRvDH0Wy?usp=share_link"
                  }
                ]
              },
              {
                name: "Data Structures and its Applications",
                subject_code: "CSE202",
                notes: [
                  {
                    title: "Data Structures Notes",
                    type: "theory",
                    link: "https://drive.google.com/drive/folders/1jQWPr4UQ_PJVcH3SJ4Y54UmpEfhNPy9p?usp=share_link"
                  },
                  {
                    title: "Data Structures Lab",
                    type: "lab",
                    link: "https://github.com/KTS-o7/Third_sem_Codes.git"
                  }
                ]
              },
              {
                name: "Foundations Of Computer Systems Design",
                subject_code: "CSE203",
                notes: [
                  {
                    title: "Computer Systems Design Notes",
                    type: "theory",
                    link: "https://drive.google.com/drive/folders/1jQWPr4UQ_PJVcH3SJ4Y54UmpEfhNPy9p?usp=share_link"
                  }
                ]
              },
              {
                name: "Operating System",
                subject_code: "CSE204",
                notes: [
                  {
                    title: "Operating Systems Notes",
                    type: "theory",
                    link: "https://drive.google.com/drive/folders/1lBZddIKXK-DcxI579FJmz2whAwR8wQxS?usp=share_link"
                  },
                  {
                    title: "Operating Systems Lab",
                    type: "lab",
                    link: "https://github.com/Developer1100x/RVCE_Operating-System_LAB"
                  }
                ]
              },
              {
                name: "Cyber Security",
                subject_code: "CSE205",
                notes: [
                  {
                    title: "Cyber Security Notes",
                    type: "theory",
                    link: "https://drive.google.com/drive/folders/1zdFygZLL_xY63FSi94JFbvArZyZogCks?usp=share_link"
                  }
                ]
              }
            ]
          },
          {
            number: 4,
            subjects: [
              {
                name: "Microcontrollers and Embedded CS Systems",
                subject_code: "CSE301",
                notes: [
                  {
                    title: "Embedded Systems Study Materials",
                    type: "theory",
                    link: "https://drive.google.com/drive/folders/1DmPr9Eu2cL-4zpYZGAyDBvsU1hChJxxI?usp=share_link"
                  }
                ]
              },
              {
                name: "Design and Analysis of Algorithms",
                subject_code: "CSE302",
                notes: [
                  {
                    title: "Algorithms Study Materials",
                    type: "theory",
                    link: "https://drive.google.com/drive/folders/13r_ZfVkEzmFTQLZZYOS-G72XMnIDI-4R?usp=share_link"
                  },
                  {
                    title: "Algorithms Lab",
                    type: "lab",
                    link: "https://github.com/KTS-o7/LAB_Programs_Rvce_2ndYear"
                  }
                ]
              },
              {
                name: "Computer Networks",
                subject_code: "CSE303",
                notes: [
                  {
                    title: "Computer Networks Notes",
                    type: "theory",
                    link: "https://drive.google.com/drive/folders/1HiECWH3vlzA-q6NIODTWTEt5EZ7HrTyj?usp=share_link"
                  }
                ]
              },
              {
                name: "Object Oriented Programming Using JAVA",
                subject_code: "CSE304",
                notes: [
                  {
                    title: "OOP Using Java Notes",
                    type: "theory",
                    link: "https://drive.google.com/drive/folders/1tJUoX0yU8mBZwsAQtUvFS-kitHzpA3Il?usp=share_link"
                  },
                  {
                    title: "Java Lab Programs",
                    type: "lab",
                    link: "https://github.com/KTS-o7/Java_OOPS_Codes"
                  }
                ]
              }
            ]
          }
        ]
      },
      {
        year: 3,
        semesters: [
          {
            number: 5,
            subjects: [
              {
                name: "Theory of Computation",
                subject_code: "CSE501",
                notes: [
                  {
                    title: "Theory of Computation Notes",
                    type: "theory",
                    link: "https://drive.google.com/drive/folders/1R6SE95wmwiw1sSCT8muTsMrkuwbvcouh?usp=share_link"
                  }
                ]
              },
              {
                name: "Artificial Intelligence and Machine Learning",
                subject_code: "CSE502",
                notes: [
                  {
                    title: "AI & ML Study Materials",
                    type: "theory",
                    link: "https://drive.google.com/drive/folders/1uihWNnIv_wBtUiaJSYH2UmuegNxpS-hQ?usp=share_link"
                  }
                ]
              },
              {
                name: "Database Management Systems",
                subject_code: "CSE503",
                notes: [
                  {
                    title: "DBMS Notes",
                    type: "theory",
                    link: "https://drive.google.com/drive/folders/1liFDF1IDCsEdRsv7iT_e-sfCzj7va6P6?usp=share_link"
                  }
                ]
              },
              {
                name: "AIISE",
                subject_code: "CSE504",
                notes: [
                  {
                    title: "AIISE Notes",
                    type: "theory",
                    link: "https://drive.google.com/drive/folders/1Y_g1Eeg7xLP11eUAZM9BzCpLUi6phkWh?usp=share_link"
                  }
                ]
              },
              {
                name: "ANN&DL",
                subject_code: "CSE505",
                notes: [
                  {
                    title: "ANN & DL Notes",
                    type: "theory",
                    link: "https://drive.google.com/drive/folders/1ea7gRgo6o4ebi8UgxXaHOVFQlfEF_bYK?usp=share_link"
                  }
                ]
              },
              {
                name: "Network Programming",
                subject_code: "CSE506",
                notes: [
                  {
                    title: "Network Programming Lab",
                    type: "lab",
                    link: "https://github.com/18praneeth/RVCE-5th-Sem-CSE-lab-programs-NPS"
                  }
                ]
              }
            ]
          },
          {
            number: 6,
            subjects: [
              {
                name: "Compiler Design",
                subject_code: "CSE601",
                notes: [
                  {
                    title: "Compiler Design Notes",
                    type: "theory",
                    link: "https://drive.google.com/drive/folders/1pcGM_-rQ5YhZWfQ8ys7RDgcvbkKb762M?usp=sharing"
                  },
                  {
                    title: "Compiler Design Lab",
                    type: "lab",
                    link: "https://github.com/Abhishek0R/Compiler-Design-Lab-Programs"
                  }
                ]
              },
              {
                name: "Software Engineering",
                subject_code: "CSE602",
                notes: [
                  {
                    title: "Software Engineering Notes",
                    type: "theory",
                    link: "https://drive.google.com/drive/folders/1eyCTieB177fPz1ENbQaADwCN2HQtgVml?usp=sharing"
                  }
                ]
              }
            ]
          }
        ]
      },
      {
        year: 4,
        semesters: [
          {
            number: 7,
            subjects: [
              {
                name: "Parallel Architecture and Distributed Programming",
                subject_code: "CSE701",
                notes: [
                  {
                    title: "Parallel Architecture Notes",
                    type: "theory",
                    link: "https://drive.google.com/drive/folders/1crGg0k3Qsq7XqhtahZACIEOk3Z4vdy1B?usp=share_link"
                  },
                  {
                    title: "PADP Lab",
                    type: "lab",
                    link: "https://github.com/Shreyas-Shankar155/PADPLab"
                  }
                ]
              },
              {
                name: "LINUX INTERNAL",
                subject_code: "CSE702",
                notes: [
                  {
                    title: "Linux Internal Notes",
                    type: "theory",
                    link: "https://drive.google.com/drive/folders/1Bl3QakxiyelhVkEH0tzAfk3l9liTiyIr?usp=sharing"
                  }
                ]
              },
              {
                name: "Information Storage Management",
                subject_code: "CSE703",
                notes: []
              }
            ]
          }
        ]
      }
    ]
  },


  // Other departments remain unchanged...


  {
    name: "Electrical Engineering",
    description:
      "Find resources for Electrical Engineering courses, covering circuit theory, power systems, control systems, and electrical machines.",
    link: "/eee",
    years: [
      {
        year: 1,
        semesters: [
          {
            number: 1,
            subjects: [
              {
                name: "Circuit Theory",
                subject_code: "EEE101",
                notes: [
                  {
                    title: "Basic Circuit Analysis",
                    type: "theory",
                    link: "https://drive.google.com/...",
                  },
                  {
                    title: "Circuit Lab Manual",
                    type: "lab",
                    link: "https://drive.google.com/...",
                  },
                ],
              },
            ],
          },
        ],
      },
    ],
  },

   
    {
      name: "Aerospace Engineering",
      description: "Study materials for Aerospace Engineering, covering aerodynamics, propulsion, and aerospace systems.",
      link: "/aerospace",
      years: [
        {
          year: 2,
          semesters: [
            {
              number: 3,
              subjects: [
                {
                  name: "Aerodynamics",
                  subject_code: "AE201",
                  notes: [
                    {
                      title: "Basic Aerodynamics Notes",
                      type: "theory",
                      link: "https://drive.google.com/...",
                    },
                    {
                      title: "Aerodynamics Lab Guide",
                      type: "lab",
                      link: "https://drive.google.com/...",
                    },
                  ],
                },
              ],
            },
          ],
        },
      ],
    },
    {
      name: "Biotechnology",
      description: "Comprehensive study resources for Biotechnology, including genetic engineering, microbiology, and bioprocessing.",
      link: "/biotech",
      years: [
        {
          year: 2,
          semesters: [
            {
              number: 3,
              subjects: [
                {
                  name: "Genetic Engineering",
                  subject_code: "BIO201",
                  notes: [
                    {
                      title: "Gene Editing Techniques",
                      type: "theory",
                      link: "https://drive.google.com/...",
                    },
                    {
                      title: "Bio Lab Manual",
                      type: "lab",
                      link: "https://drive.google.com/...",
                    },
                  ],
                },
              ],
            },
          ],
        },
      ],
    },
    {
      name: "Chemical Engineering",
      description: "Study materials for Chemical Engineering, covering process dynamics, chemical reactions, and thermodynamics.",
      link: "/chemeng",
      years: [
        {
          year: 2,
          semesters: [
            {
              number: 3,
              subjects: [
                {
                  name: "Thermodynamics",
                  subject_code: "CHE201",
                  notes: [
                    {
                      title: "Thermodynamics Principles",
                      type: "theory",
                      link: "https://drive.google.com/...",
                    },
                    {
                      title: "Chemical Processes Lab Guide",
                      type: "lab",
                      link: "https://drive.google.com/...",
                    },
                  ],
                },
              ],
            },
          ],
        },
      ],
    },
    
    {
      name: "Civil Engineering",
      description: "Study resources for Civil Engineering, including structural analysis, building materials, and construction practices.",
      link: "/civil",
      years: [
        {
          year: 2,
          semesters: [
            {
              number: 3,
              subjects: [
                {
                  name: "Structural Analysis",
                  subject_code: "CIVIL201",
                  notes: [
                    {
                      title: "Basic Structural Mechanics",
                      type: "theory",
                      link: "https://drive.google.com/...",
                    },
                    {
                      title: "Civil Engineering Lab Guide",
                      type: "lab",
                      link: "https://drive.google.com/...",
                    },
                  ],
                },
              ],
            },
          ],
        },
      ],
    },
    // Repeat similarly for other departments
 
  
  {
    name: "Mechanical Engineering",
    description:
      "Explore study materials for Mechanical Engineering, including thermodynamics, mechanics, manufacturing processes, and CAD/CAM.",
    link: "/mech",
    years: [
      {
        year: 1,
        semesters: [
          {
            number: 1,
            subjects: [
              {
                name: "Engineering Mechanics",
                subject_code: "MECH101",
                notes: [
                  {
                    title: "Statics and Dynamics",
                    type: "theory",
                    link: "https://drive.google.com/...",
                  },
                  {
                    title: "2023 Mid-term Paper",
                    type: "question-paper",
                    link: "https://drive.google.com/...",
                  },
                ],
              },
              {
                name: "Engineering Drawing",
                subject_code: "MECH102",
                notes: [
                  {
                    title: "AutoCAD Basics",
                    type: "lab",
                    link: "https://drive.google.com/...",
                  },
                ],
              },
              {
                name: "Engineering Drawing 2",
                subject_code: "MECH102",
                notes: [
                  {
                    title: "AutoCAD Basics",
                    type: "lab",
                    link: "https://drive.google.com/...",
                  },
                ],
              },
            ],
          },
        ],
      },
    ],
  },
  {
    name: "Electronics & Communication",
    description:
      "Access resources for Electronics and Communication Engineering, covering digital electronics, communication systems, and signal processing.",
    link: "/ece",
    years: [
      {
        year: 1,
        semesters: [
          {
            number: 1,
            subjects: [
              {
                name: "Digital Electronics",
                subject_code: "ECE101",
                notes: [
                  {
                    title: "Boolean Algebra and Logic Gates",
                    type: "theory",
                    link: "https://drive.google.com/...",
                  },
                  {
                    title: "Digital Lab Manual",
                    type: "lab",
                    link: "https://drive.google.com/...",
                  },
                ],
              },
            ],
          },
        ],
      },
    ],
  },
];

export const contributors: Contributors[] = [
  {
    name: "John Doe",
    link: "https://github.com/johndoe",
    notes_contributed: 10,
    department: "Computer Science",
    year: 1,
  },
  {
    name: "Jane Doe",
    link: "https://github.com/janedoe",
    notes_contributed: 5,
    department: "Electrical Engineering",
    year: 2,
  },
  {
    name: "John Doe",
    link: "https://github.com/johndoe",
    notes_contributed: 10,
    department: "Computer Science",
    year: 1,
  },
];
